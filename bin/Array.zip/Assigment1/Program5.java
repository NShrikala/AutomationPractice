package Assigment1;

public class Program5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {10,20,20,30,40,50,50,60,60,60};
		// for each
		for(int a : arr)
		{
			System.out.println("Value of array is :  "+ a);
		}
	}

}
