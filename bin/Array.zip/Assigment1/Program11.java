package Assigment1;

public class Program11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {10,0,30,40,50,60,510,80,90,300};
		
		System.out.println("Number of Elements present in array is : - "+ arr.length);
	}

}
