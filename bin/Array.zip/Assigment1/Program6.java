package Assigment1;

public class Program6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {10,20,30,40,50,60};
		
		System.out.println("Reverse Order of Array Element is : ");
		for(int a = arr.length-1; a>=0; a--)
		{
			System.out.println(arr[a]);
		}
		
		
	}

}
