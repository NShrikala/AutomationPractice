package Assigment1;

public class Program1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {10,20,30,40,50};
		
		int[] arr2 = new int[5];
		
		
		for(int a = 0 ; a<arr.length; a++)
		{
			arr2[a] = arr[a]; 
			System.out.println("Element Copied :-  "+ arr2[a]);
		//	System.out.println("Array1 "+ arr[a]);
		}
		
		
		
	}

}
